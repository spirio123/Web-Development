<!DOCTYPE html>
<html lang="en">
<head>
 <title>A very simple webpage</title>
 <meta charset="UTF-8" />
</head>
<body>
<h1>A very simple webpage. This is an "h1" level header. </h1>
 <h2>This is a level h2 header. </h2>
 <h6>This is a level h6 header. Pretty small!</h6>
 <p>This is a standard paragraph.</p>
 <h2>How about a nice ordered list!</h2>
 <ol>
 <li>went to market
 <li> went to Web programming class
 <li> went to restaurant
 </ol>
 <h2>Unordered list</h2>
 <ul>
 <li>First element
 <li>Second element
 <li>Third element
 </ul>
 <h2>Nested Lists!</h2>
 <ul>
 <li>Things to to today:
 <ol>
 <li>Walk the dog
 <li>Feed the cat
<li>Mow the lawn
 </ol>
 <li>Things to do tomorrow:
 <ol>
 <li>Lunch with mom
<li>Feed the hamster
 <li>Clean kitchen
 </ol>
 </ul>
</body>
</html>